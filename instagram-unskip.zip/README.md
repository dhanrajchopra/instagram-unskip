# Instagram Unskip

> A Claude skill that engineers Instagram content to survive the first second.

Most Instagram posts fail at second one. Not because the content is bad — because the first frame asks the viewer to invest before earning the investment. **Instagram Unskip** is a [Claude skill](https://docs.claude.com/en/docs/skills) that teaches Claude how to produce Instagram content engineered against the behavioral metrics Instagram's algorithm actually uses to decide reach.

It works on Reels, carousels, and single-image posts. It does *not* cover Stories, Lives, or Broadcast Channels.

---

## What it fixes

Instagram has shifted. Likes and comments are now validation signals — they tell creators their content was enjoyed, but they barely move reach. Distribution is driven by a different stack:

1. **Skip Rate** — % who swipe away in the first ~3 seconds. The single biggest reach killer.
2. **Share Rate** — % who DM the post. The primary virality driver.
3. **Save Rate** — signals lasting value.
4. **Repost Rate** — Story amplification.
5. **Comment Rate** — secondary.
6. **Like Rate** — output, not input.

Most posts die on metric #1 and never reach metric #2. This skill engineers for both — every output is designed to lower skip rate and raise share rate first, with the others as supporting layers.

---

## What's in the skill

Self-contained in a single `SKILL.md`. No external dependencies. It embeds:

- The 6-metric Instagram reach hierarchy and the creative tactics that move each one
- The **SUCCESs** message-design framework (Simple, Unexpected, Concrete, Credible, Emotional, Stories) — adapted for Instagram
- Format playbooks for **Reels** (15–30s structure, hook formulas, on-screen text rules), **Carousels** (slide-by-slide responsibility, content patterns), and **Statics**
- **Caption craft** — structure, length per format, hook formulas, rules
- **Visual direction defaults** — elegant, premium, restrained, with negative space
- A **production workflow** that stress-tests the brief, finds the Commander's Intent, engineers the metric stack, filters through SUCCESs, and self-audits before delivery
- A worked example: BEFORE (generic agency carousel) vs. AFTER (with the skill applied)

---

## Installation

The skill works identically across Claude.ai, Claude Code, and the Claude API.

### Claude Code

```bash
git clone https://github.com/YOUR_USERNAME/instagram-unskip.git
cp -r instagram-unskip/instagram_unskip ~/.claude/skills/
```

Or commit it to your project at `.claude/skills/instagram_unskip/`.

### Claude.ai (web / mobile)

1. Open Settings → Capabilities → Skills
2. Upload the `instagram_unskip` folder (or `SKILL.md` directly, depending on the UI)

### Claude API

Upload via the `/v1/skills` endpoint. See [Anthropic's Skills API documentation](https://docs.claude.com/en/api/skills) for details.

---

## How to use it

Once installed, just describe what you want. The skill triggers on phrases like:

- "Make me a carousel on [topic]"
- "Write a reel script about [topic]"
- "Fix this Instagram post" *(paste post)*
- "My reels aren't reaching — why?"
- "Caption for this Instagram post"

Claude will run the production workflow: stress-test the brief, find the core, engineer the metric stack, produce the artifact, write the caption, and deliver a self-audit explaining what defends skip rate, what drives shares, and what the CTA is doing.

---

## Example: BEFORE vs. AFTER

**Brief:** "Make me a carousel on why marketing automation setups leak leads."

**Without the skill:**
- Slide 1: "Why Most Marketing Automation Setups Leak Leads"
- 5 equal-weight tips
- "Follow for more!" CTA
- Caption echoes the visual

**With the skill:**
- Slide 1: *"Your marketing automation isn't broken. Your sales handoff is."* (contrarian inversion of the brief itself)
- Commander's Intent: *Fix the handoff, not the funnel.*
- 3 symptoms → 1 fix → screenshot-ready insight slide
- CTA: *"Send this to your sales lead."* (engineered for share rate)
- Caption adds the argument the slides imply
- Delivered with a self-audit explaining each design choice

Full worked example is in the [SKILL.md](./instagram_unskip/SKILL.md#worked-example).

---

## Scope

**In scope:** Reels, carousels, single-image (static) posts.

**Out of scope:**

- Paid Instagram ads (use a paid-ads-focused skill)
- Non-Instagram platforms — LinkedIn, TikTok, X, YouTube (use a generalist social skill)
- Stories, Lives, Broadcast Channels
- Generating finished video files (this skill produces scripts, shot lists, on-screen text, visual direction — rendering happens in CapCut, Premiere, etc.)
- Scheduling and analytics

---

## Compatibility

| Surface | Supported |
|---------|-----------|
| Claude.ai (web, mobile, desktop) | ✅ |
| Claude Code | ✅ |
| Claude API | ✅ |
| Other agent platforms supporting [Agent Skills](https://agentskills.io) | ✅ |

The skill is a single Markdown file with YAML frontmatter — it follows the open Agent Skills standard.

---

## Versioning

- **1.0.0** — Initial release. Reels, carousels, statics. Stories/Lives/Broadcast Channels deferred to v2.

---

## License

[MIT](./LICENSE). Use it, modify it, ship it, sell it. Attribution appreciated but not required.

---

## Contributing

Open an issue or PR if you find a sharper way to express something, a tactic that doesn't actually work, or a failure mode worth adding. Keep changes scoped to Instagram — cross-platform additions belong in a different skill.

---

## Credits

The reach-hierarchy framing draws on creator insights from `@ssupcreators` and public statements by Adam Mosseri, head of Instagram. The SUCCESs framework comes from *Made to Stick* by Chip & Dan Heath. Everything else is original synthesis.
